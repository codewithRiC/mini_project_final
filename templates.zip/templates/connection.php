<?php
    $severname = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mini";

    $conn = mysqli_connect($severname, $username, $password, $dbname);

    if($conn){
        
    }else{
        echo "Connection Failed";
    }

?>




















