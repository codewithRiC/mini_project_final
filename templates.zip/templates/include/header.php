<header class="topheader">
        
        <div class="logo">
            <img src="css/logo.png" alt="logo">
        </div>
        <div class="topheader-name">
            <h1>Ultimate Marketing Solution</h1>
        </div>
        <div class="log-out">
          
          <!-- <input placeholder="Search " class="search-input">
          <div class="search-icon">
              <i class="fa-solid fa-magnifying-glass"></i>
          </div> -->
          <a href="login.php">Log Out</a>
          <div class="log-out-icon">
              <i class="fa-solid fa-right-from-bracket"></i>
          </div>
      </div>

     
  </header>